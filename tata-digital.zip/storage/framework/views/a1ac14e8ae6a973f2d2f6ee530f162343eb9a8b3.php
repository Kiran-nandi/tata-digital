<!DOCTYPE html>
<html lang="en">
<head>
  <title>TATA DIGITAL</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body style="overflow-x: hidden;">
    <style>
        @media  only screen and (min-width: 1200px) {
.deskhide {
  display: none;
}
}
@media  only screen and (max-width: 1200px) {
  .mobhide {
    display: none;
  }
}
        @media  only screen and (max-width: 900px){
        .mar-top {
            margin-top: 15% !important;
            padding-left: 8% !important;
            padding-right: 8% !important;
        }
    }
    </style>
    
<div style="background-color: #f2f4f3;width: 100%;position: absolute;">
<nav class="navbar navbar-expand-sm " style="float: right;">
  <ul class="navbar-nav" >
    <li class="nav-item">
      <a class="nav-link" href="/admin/logout" style="color: #000;">Logout</a>
    </li>
  </ul>
</nav>
</div>
<br>
<section>
    <div class="row mar-top mobhide" style="padding-left:3%;padding-right: 3%; margin-top: 3%;">
        <h2 style="margin-bottom: 1%;">Contact List</h2>
        <div style="width: 100%;margin-top: -50px;">
            <a href="/admin/exportfile" class="btn btn-primary" style="float: right;">Export File</a>
        </div>
        
        <!-- <p>The .table class adds basic styling (light padding and horizontal dividers) to a table:</p>             -->
        <table class="table">
          <thead>
            <tr>
              <th>Id</th>
              <th>Entity Name</th>
              <th>Contact Person Name</th>
              <th>Contact Detials</th>
              <th>Address</th>
              <th style="width: 15%;">Shop Img</th>
              <th>Other Cities</th>
              <th>PTL or FTL</th>
              <th>Organisation</th>
              <th>Proper Bills</th>
              <th style="width: 15%;">Visiting Card</th>
              <th>Delete</th>
            </tr>
          </thead>
          <tbody>
              <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $digitalform): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($digitalform->id); ?></td>
              <td><?php echo e($digitalform->name_entity); ?></td>
              <td><?php echo e($digitalform->contact_name); ?></td>
              <td><?php echo e($digitalform->contact_detials); ?></td>
              <td><?php echo e($digitalform->address); ?></td>
              <td>
                <img src="<?php echo e(asset('photo_shop_upload/'.$digitalform->photo_shop)); ?>" style="width:100%;"/>
              </td>
              <td><?php echo e($digitalform->other_cities); ?></td>
              <td><?php echo e($digitalform->ptl_or_ftl); ?></td>
              <td><?php echo e($digitalform->organization); ?></td>
              <td><?php echo e($digitalform->proper_bills); ?></td>
              <td>
                <img src="<?php echo e(asset('visiting_card_upload/'.$digitalform->photo_visiting_card)); ?>" style="width:100%;"/>
              </td>
              <td>
                <a onclick="return deletenow()" href="/admin/deletecontact/<?php echo e($digitalform->id); ?>">
                    Delete
                </a>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
          </tbody>
          <script>
            function deletenow()
            {
                return confirm("are you sure u want to delete the item ??");
            }
        </script>
        </table>
      </div>

      <!-- code for mobile -->


      <div class="row mar-top deskhide" style="padding-left:3%;padding-right: 3%; margin-top: 3%;">
        <h2 style="margin-bottom: 5%;">Contact List</h2>
        <div style="width: 100%;margin-top: -50px;">
            <a href="/admin/exportfile" class="btn btn-primary" style="float: right;">Export File</a>
        </div>
        
        <!-- <p>The .table class adds basic styling (light padding and horizontal dividers) to a table:</p>             -->
        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $digitalform): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <table class="table" style="margin-bottom: 5%;">
            <tr>
                <th>
                    Id
                </th>
                <td><?php echo e($digitalform->id); ?></td>
            </tr>
            <tr>
                <th>Entity Name</th>
                <td><?php echo e($digitalform->name_entity); ?></td>
            </tr>
            <tr>
                <th>Contact Person Name</th>
                <td><?php echo e($digitalform->contact_name); ?></td>
            </tr>
            <tr>
                <th>Contact Detials</th>
                <td><?php echo e($digitalform->contact_detials); ?></td>
            </tr>
            <tr>
                <th>Address</th>
                <td><?php echo e($digitalform->address); ?></td>
            </tr>
            <tr>
                <th style="width: 15%;">Shop Img</th>
                <td>
                    <img src="<?php echo e(asset('photo_shop_upload/'.$digitalform->photo_shop)); ?>" style="width:100%;"/>
                  </td>
            </tr>
            <tr>
                <th>Other Cities</th>
                <td><?php echo e($digitalform->other_cities); ?></td>
            </tr>
            <tr>
                <th>PTL or FTL</th>
                <td><?php echo e($digitalform->ptl_or_ftl); ?></td>
            </tr>
            <tr>
                <th>Organisation</th>
                <td><?php echo e($digitalform->organization); ?></td>
            </tr>
            <tr>
                <th>Proper Bills</th>
                <td><?php echo e($digitalform->proper_bills); ?></td>
            </tr>
            <tr>
                <th style="width: 15%;">Visiting Card</th>
                <td>
                    <img src="<?php echo e(asset('visiting_card_upload/'.$digitalform->photo_visiting_card)); ?>" style="width:100%;"/>
                  </td>
            </tr>
            <tr>
                <th>Delete</th>
                <td>
                    <a onclick="return deletenow()" href="/admin/deletecontact/<?php echo e($digitalform->id); ?>">
                        Delete
                    </a>
                  </td>
            </tr>
        </table>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
          <!-- <thead>
            <tr>
              <th>Id</th>
              <th>Entity Name</th>
              <th>Contact Person Name</th>
              <th>Contact Detials</th>
              <th>Address</th>
              <th style="width: 15%;">Shop Img</th>
              <th>Other Cities</th>
              <th>PTL or FTL</th>
              <th>Organisation</th>
              <th>Proper Bills</th>
              <th style="width: 15%;">Visiting Card</th>
              <th>Delete</th>
            </tr>
          </thead>
          <tbody>
              <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $digitalform): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($digitalform->id); ?></td>
              <td><?php echo e($digitalform->name_entity); ?></td>
              <td><?php echo e($digitalform->contact_name); ?></td>
              <td><?php echo e($digitalform->contact_detials); ?></td>
              <td><?php echo e($digitalform->address); ?></td>
              <td>
                <img src="<?php echo e(asset('photo_shop_upload/'.$digitalform->photo_shop)); ?>" style="width:100%;"/>
              </td>
              <td><?php echo e($digitalform->other_cities); ?></td>
              <td><?php echo e($digitalform->ptl_or_ftl); ?></td>
              <td><?php echo e($digitalform->organization); ?></td>
              <td><?php echo e($digitalform->proper_bills); ?></td>
              <td>
                <img src="<?php echo e(asset('visiting_card_upload/'.$digitalform->photo_visiting_card)); ?>" style="width:100%;"/>
              </td>
              <td>
                <a onclick="return deletenow()" href="/admin/deletecontact/<?php echo e($digitalform->id); ?>">
                    Delete
                </a>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
          </tbody> -->
          <script>
            function deletenow()
            {
                return confirm("are you sure u want to delete the item ??");
            }
        </script>
        <!-- </table> -->
      </div>
</section>



</body>
</html>
<?php /**PATH E:\xampp\htdocs\tata-digital\resources\views/list.blade.php ENDPATH**/ ?>