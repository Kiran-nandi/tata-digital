<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class digitalform extends Model
{
    //
    protected $table='main';  
    protected $fillable=['name_entity','contact_name','contact_detials','address','photo_shop','other_cities','ptl_or_ftl','organization','proper_bills','photo_visiting_card','created_at','updated_at'];
}
