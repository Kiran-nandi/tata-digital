<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Http\Request;
use \Illuminate\Http\Response;
use DB;
use Redirect;
use App\digitalform;

session_start();

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function login(Request $request)
    {
        //admin login
        $request->validate([  
            'Username'=>'required',  
            'Password'=>'required',
        ]);  
        
        // $login = new User;

        $username = $request->get('Username');
        $password = $request->get('Password');
    
            $check = DB :: select('select * from admin where username=? and password = ?',[$username,$password]);
            if($check) {
                $_SESSION['user_name']=$username;
                return Redirect::to('/admin/list');
            }
            else {
                return Redirect::to('/admin');
            }

    }

    public function logout(Request $request) {
        session_unset();
        return Redirect::to('/admin');
    }
    public function list(Request $request) {
        if (!empty($_SESSION['user_name'])) {
            $fulllist = digitalform::all();
            return view('list',['list'=>$fulllist]);
        }
        else {
            return Redirect::to('/admin');
        }
    }
    public function admin(Request $request) {
        return view('admin');
    }
    

    public function home() {
        return view('home');
    }

    public function formsubmit(Request $request){

        $shopphoto = $request->file('shopphoto');
        $destpathshop = 'photo_shop_upload';
        $shopphoto->move($destpathshop,$shopphoto->getClientOriginalName());

        $photo_visiting_card = $request->file('photo_visiting_card');
        $destpathvisiting = 'visiting_card_upload';
        $photo_visiting_card->move($destpathvisiting,$photo_visiting_card->getClientOriginalName());

        $digitalform = new digitalform;
        

        $digitalform->name_entity = $request->get('name_of_entity');
        $digitalform->contact_name = $request->get('contact_name');
        $digitalform->contact_detials = $request->get('contact_detial');
        $digitalform->address = $request->get('address');
        $digitalform->photo_shop = $shopphoto->getClientOriginalName();
        $digitalform->other_cities = $request->get('cities');
        $digitalform->ptl_or_ftl = $request->get('ptl');
        $digitalform->organization = $request->get('organization');
        $digitalform->proper_bills = $request->get('bills');
        $digitalform->photo_visiting_card = $photo_visiting_card->getClientOriginalName();
        
        if($digitalform->save()) {
            return Redirect::to('/');
        }
        else {
            return "Please try again";
        }

    }

    public function delete(Request $request, $id) {
        if (!empty($_SESSION['user_name'])) {
            $list = digitalform::find($id);
            if($list->delete()) {
                return Redirect::to('/admin/list');
            }
            else {
                return Redirect::to('/admin/list');
            }
        }
        else {
            return Redirect::to('/admin');
        }
    }

    public function exportfile() {
        if (!empty($_SESSION['user_name'])) {
            $fulllist = digitalform::all();

            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename=contactlist.csv');
            $output = fopen('php://output', 'w');
            fputcsv($output, array('ID', 
            'Name of the entity', 
            'Contact person name', 
            'Contact detial', 
            'Address', 
            'Photo of the shop/Geo tag',
            'Do you send materials/goods to other cities in india',
            'Do you send materials in PTL or FTL',
            'Type of organisation',
            'Do you send materials with proper bills',
            'Photo of visiting card',
            'Date'));
            foreach($fulllist as $row) {
                fputcsv($output, array($row['id'],
                $row['name_entity'],
            $row['contact_name'],
            $row['contact_detials'],
            $row['address'],
            $row['photo_shop'],
            $row['other_cities'],
            $row['ptl_or_ftl'],
            $row['organization'],
            $row['proper_bills'],
            $row['photo_visiting_card'],
            $row['created_at'],
            ));
            }
            // <img src="{{ asset("photo_shop_upload/"'.$row["photo_shop"].') }}" style="width:100%;"/>
        }
        else {
            return Redirect::to('/admin');
        }
    }


}
